/*
 * Author - Jan Dufek, dufeja@gmail.com
 * Copying and using only with permission of the author.
 */
package cz.cvut.fit.vmw.genre.db;

/**
 *
 * @author Jan Dufek
 */
public interface FeatureDAO {
    
}
