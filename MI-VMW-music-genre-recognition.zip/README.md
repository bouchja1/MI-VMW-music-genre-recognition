MI-VMW-music-genre-recognition
==============================

School project at FIT CTU, Prague. Music genre recognition (using jAudio).
